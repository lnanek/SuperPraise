/** Automatically generated file. DO NOT MODIFY */
package com.superpraiseapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}